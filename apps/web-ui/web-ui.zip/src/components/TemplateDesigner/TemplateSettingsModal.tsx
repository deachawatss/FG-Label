import React, { memo } from 'react';
import { Modal, Form, Input, Select, Row, Col, InputNumber } from 'antd';
import { TemplateInfo, CanvasSize } from '../../models/TemplateDesignerTypes';

const { Option } = Select;

interface TemplateSettingsModalProps {
  visible: boolean;
  onCancel: () => void;
  onSave: (templateInfo: TemplateInfo, canvasSize: CanvasSize) => void;
  templateInfo: TemplateInfo;
  canvasSize: CanvasSize;
  loading: boolean;
}

/**
 * Modal component for template settings
 */
export const TemplateSettingsModal: React.FC<TemplateSettingsModalProps> = memo(({
  visible,
  onCancel,
  onSave,
  templateInfo,
  canvasSize,
  loading
}) => {
  const [form] = Form.useForm();

  // Set form values when visible or templateInfo changes
  React.useEffect(() => {
    if (visible) {
      form.setFieldsValue({
        ...templateInfo,
        width: canvasSize.width,
        height: canvasSize.height
      });
    }
  }, [visible, templateInfo, canvasSize, form]);

  const handleSubmit = () => {
    form.validateFields().then(values => {
      const { width, height, ...restValues } = values;
      onSave(restValues, { width, height });
    });
  };

  return (
    <Modal
      title="Template Settings"
      open={visible}
      onCancel={onCancel}
      onOk={handleSubmit}
      confirmLoading={loading}
      width={700}
    >
      <Form
        form={form}
        layout="vertical"
        initialValues={{
          ...templateInfo,
          width: canvasSize.width,
          height: canvasSize.height
        }}
      >
        <Row gutter={16}>
          <Col span={24}>
            <Form.Item
              name="name"
              label="Template Name"
              rules={[{ required: true, message: 'Please enter a template name' }]}
            >
              <Input placeholder="Enter template name" />
            </Form.Item>
          </Col>
        </Row>
        <Row gutter={16}>
          <Col span={24}>
            <Form.Item
              name="description"
              label="Description"
            >
              <Input.TextArea placeholder="Enter template description" rows={2} />
            </Form.Item>
          </Col>
        </Row>
        <Row gutter={16}>
          <Col span={12}>
            <Form.Item
              name="productKey"
              label="Product Code"
            >
              <Input placeholder="Enter product code" />
            </Form.Item>
          </Col>
          <Col span={12}>
            <Form.Item
              name="customerKey"
              label="Customer Code"
            >
              <Input placeholder="Enter customer code" />
            </Form.Item>
          </Col>
        </Row>
        <Row gutter={16}>
          <Col span={12}>
            <Form.Item
              name="paperSize"
              label="Paper Size"
              initialValue="4x4"
            >
              <Select>
                <Option value="4x4">4 x 4 inches</Option>
                <Option value="4x6">4 x 6 inches</Option>
                <Option value="A4">A4</Option>
                <Option value="A5">A5</Option>
                <Option value="Custom">Custom</Option>
              </Select>
            </Form.Item>
          </Col>
          <Col span={12}>
            <Form.Item
              name="orientation"
              label="Orientation"
              initialValue="Portrait"
            >
              <Select>
                <Option value="Portrait">Portrait</Option>
                <Option value="Landscape">Landscape</Option>
              </Select>
            </Form.Item>
          </Col>
        </Row>
        <Row gutter={16}>
          <Col span={12}>
            <Form.Item
              name="width"
              label="Width (pixels)"
              rules={[{ required: true, message: 'Please enter width' }]}
            >
              <InputNumber min={100} max={2000} style={{ width: '100%' }} />
            </Form.Item>
          </Col>
          <Col span={12}>
            <Form.Item
              name="height"
              label="Height (pixels)"
              rules={[{ required: true, message: 'Please enter height' }]}
            >
              <InputNumber min={100} max={2000} style={{ width: '100%' }} />
            </Form.Item>
          </Col>
        </Row>
        <Row gutter={16}>
          <Col span={24}>
            <Form.Item
              name="templateType"
              label="Template Type"
              initialValue="Standard"
            >
              <Select>
                <Option value="Standard">Standard</Option>
                <Option value="INNER">Inner Label</Option>
                <Option value="OUTER">Outer Label</Option>
                <Option value="MASTER">Master</Option>
              </Select>
            </Form.Item>
          </Col>
        </Row>
      </Form>
    </Modal>
  );
});

TemplateSettingsModal.displayName = 'TemplateSettingsModal'; 