import React, { useState, useCallback, useEffect, useRef } from 'react';
import { Layout, message, Modal, Input } from 'antd';
import { useRouter } from 'next/router';
import { v4 as uuidv4 } from 'uuid';

// Import components
import { DesignerSidebar } from './DesignerSidebar';
import { DesignerToolbar } from './DesignerToolbar';
import { ElementRenderer } from './ElementRenderer';
import { TemplateSettingsModal } from './TemplateSettingsModal';

// Import custom hooks
import { useQrAndBarcode } from '../../hooks/designer/useQrAndBarcode';
import { useBatchData } from '../../hooks/designer/useBatchData';
import { useCanvasHistory } from '../../hooks/designer/useCanvasHistory';
import { useTemplateActions } from '../../hooks/designer/useTemplateActions';
import { useCanvasRenderer } from '../../hooks/designer/useCanvasRenderer';

// Import types and constants
import { ElementType, TemplateInfo, CanvasSize } from '../../models/TemplateDesignerTypes';
import { FEATURES } from '../../utils/template/constants';

/**
 * Component for checking if we're on the client side
 */
const isClient = typeof window !== 'undefined';

// Import modules that work only on the client side
let Stage: any = null;
let Layer: any = null;
let Transformer: any = null;
let Line: any = null;
let Group: any = null;
let Rect: any = null;

if (isClient) {
  const Konva = require('react-konva');
  Stage = Konva.Stage;
  Layer = Konva.Layer;
  Transformer = Konva.Transformer;
  Line = Konva.Line;
  Group = Konva.Group;
  Rect = Konva.Rect;
}

const { Header, Sider, Content } = Layout;

interface TemplateDesignerProps {
  templateId?: string;
  initialTemplate?: any;
  onSave?: (templateData: any) => Promise<void>;
}

/**
 * Component for Template Designer
 */
const TemplateDesigner: React.FC<TemplateDesignerProps> = ({ 
  templateId: templateIdProp, 
  initialTemplate,
  onSave
}) => {
  // State variables
  const [batchNo, setBatchNo] = useState<string>('');
  const [templateInfoModal, setTemplateInfoModal] = useState<boolean>(false);
  const [importJson, setImportJson] = useState<string>('');
  const [importModal, setImportModal] = useState<boolean>(false);
  const [isTemplateLoading, setIsTemplateLoading] = useState<boolean>(false);
  const [templateLoaded, setTemplateLoaded] = useState<boolean>(false);
  const [templateInfo, setTemplateInfo] = useState<TemplateInfo>({
    name: '',
    description: '',
    productKey: '',
    customerKey: '',
    paperSize: '4x4',
    orientation: 'Portrait',
    templateType: 'INNER'
  });

  // Add useRef to track if template has been loaded
  const templateLoadedRef = useRef<boolean>(false);
  const initialRenderRef = useRef<boolean>(true);
  const batchAppliedRef = useRef<{[key: string]: boolean}>({});

  // Add variable to store the last saved time
  const [lastSavedTime, setLastSavedTime] = useState<string>('');

  // Custom hooks
  const router = useRouter();
  const { 
    qrDataUrls, qrImages, barcodeDataUrls, barcodeImages,
    updateQrDataUrl, updateBarcodeDataUrl, updateAllQrCodes, updateAllBarcodes,
    clearCache
  } = useQrAndBarcode();
  
  const {
    loading: batchLoading,
    fetchBatchData,
    buildElementsFromBatch,
    findTemplateByProductAndCustomer
  } = useBatchData();
  
  const {
    elements,
    setElements,
    undo,
    redo,
    canUndo,
    canRedo,
    deleteElement,
    updateElementProperty,
    addElement,
    updateElement,
    replaceAllElements,
    duplicateElement
  } = useCanvasHistory([]);
  
  const {
    isSaving,
    isLoading,
    lastSaved,
    templateId,
    templateLoaded: templateLoadedFromActions,
    saveTemplate,
    loadTemplate,
    exportTemplateAsJson,
    importTemplateFromJson,
    setTemplateId
  } = useTemplateActions();
  
  const {
    stageRef,
    trRef,
    selectionRef,
    selectedId,
    selectedIds,
    canvasSize,
    zoom,
    dragStart,
    elementBeingCreated,
    selectionVisible,
    dragSelection,
    zoomIn,
    zoomOut,
    resetZoom,
    resizeCanvas,
    selectElement,
    selectElements,
    startCreatingElement,
    cancelCreatingElement,
    setDragStart,
    setSelectionVisible,
    setDragSelection
  } = useCanvasRenderer();

  // Side Effects
  
  // Check query parameters when loading
  useEffect(() => {
    if (!router.isReady) return;
    
    const { batchNo: batchNoParam, syncBatch, productKey, customerKey } = router.query;
    
    if (batchNoParam && typeof batchNoParam === 'string') {
      setBatchNo(batchNoParam);
      
      // Save syncBatch value for future use
      if (syncBatch === 'true' && !batchAppliedRef.current[batchNoParam]) {
        // Use setTimeout to ensure component has finished rendering once
        setTimeout(() => {
          // Check before if batch has been loaded
          if (!batchAppliedRef.current[batchNoParam]) {
            fetchAndApplyBatch(batchNoParam);
            batchAppliedRef.current[batchNoParam] = true;
          }
        }, 800);
      }
    }
    
    if (productKey && typeof productKey === 'string') {
      setTemplateInfo(prev => ({ ...prev, productKey }));
    }
    
    if (customerKey && typeof customerKey === 'string') {
      setTemplateInfo(prev => ({ ...prev, customerKey }));
    }
  }, [router.isReady, router.query]);
  
  // Load template when templateId exists - improve useEffect
  useEffect(() => {
    // Check if ready to load or already loading
    if (!router.isReady) return;
    
    // Read query parameters from URL
    const { templateId, batchNo, showQR } = router.query;
    
    // If template has already been loaded, skip this load
    if (templateLoadedRef.current) {
      console.log('Skip loading template: already loaded via templateLoadedRef');
      return;
    }
    
    // If loading in progress, skip
    if (isTemplateLoading) {
      console.log('Skip loading template: loading in progress');
      return;
    }
    
    // If templateLoaded is true, skip
    if (templateLoaded) {
      console.log('Skip loading template: already loaded via templateLoaded state');
      templateLoadedRef.current = true;
      return;
    }

    const loadInitialTemplate = async () => {
      try {
        setIsTemplateLoading(true);
        console.log('Starting to load initial template...');
        
        // Clear cache only when necessary - only once
        if (initialRenderRef.current) {
          console.log('Initial render, clearing cache');
          clearCache();
          initialRenderRef.current = false;
        }

        // If templateId exists
        if (templateId && typeof templateId === 'string') {
          console.log(`Loading template with ID: ${templateId}`);
          
          // Load template from API (do not use initialTemplate anymore)
          const templateData = await loadTemplate(templateId);
          
          if (templateData) {
            console.log('Template loaded successfully, setting state...');
            setTemplateInfo({
              name: templateData.templateInfo.name,
              description: templateData.templateInfo.description,
              productKey: templateData.templateInfo.productKey,
              customerKey: templateData.templateInfo.customerKey,
              paperSize: templateData.templateInfo.paperSize,
              orientation: templateData.templateInfo.orientation,
              templateType: templateData.templateInfo.templateType,
            });
            
            // Set canvas size according to loaded data
            if (templateData.canvasSize) {
              resizeCanvas(templateData.canvasSize);
            }
            
            // Set elements according to loaded data
            if (templateData.elements && Array.isArray(templateData.elements)) {
              console.log(`Setting ${templateData.elements.length} elements from loaded template`);
              selectElement(null);
              setElements(templateData.elements);
              
              // Update QR codes and barcodes after elements are set
              setTimeout(() => {
                console.log('Updating QR codes and barcodes after template load');
                updateAllQrCodes(templateData.elements);
                updateAllBarcodes(templateData.elements);
              }, 100);
            } else {
              console.warn('No elements or invalid elements in loaded template');
              setElements([]);
            }
            
            setTemplateLoaded(true);
            templateLoadedRef.current = true;
            console.log('Initial template setup complete');
          } else {
            console.error('Failed to load template data');
            message.error('An error occurred while loading template');
            // If load fails, consider load as complete to prevent repeated load
            setTemplateLoaded(true);
            templateLoadedRef.current = true;
          }
        } else {
          // If no templateId provided, create empty template
          console.log('No templateId provided, creating empty template');
          setElements([]);
          setTemplateLoaded(true);
          templateLoadedRef.current = true;
        }

        // Load and apply batch data if batch number exists and has not been loaded before
        if (batchNo && typeof batchNo === 'string' && !batchAppliedRef.current[batchNo]) {
          console.log(`Batch number found in URL: ${batchNo}, fetching data...`);
          fetchAndApplyBatch(batchNo);
          batchAppliedRef.current[batchNo] = true;
        }
      } catch (error) {
        console.error('Error in loadInitialTemplate:', error);
        message.error('An error occurred while loading template data');
        setTemplateLoaded(true);
        templateLoadedRef.current = true;
      } finally {
        setIsTemplateLoading(false);
      }
    };

    loadInitialTemplate();
  }, [
    router.isReady, 
    router.query, 
    loadTemplate, 
    resizeCanvas, 
    setTemplateInfo, 
    setElements, 
    selectElement, 
    updateAllQrCodes, 
    updateAllBarcodes, 
    clearCache
  ]);
  
  // Update QR codes and Barcodes when elements change - improve useEffect
  useEffect(() => {
    if (elements.length === 0) return;
    
    console.log('Checking elements for QR codes and barcodes:', elements.length, 'elements');
    
    // Filter out only qr and barcode elements
    const qrElements = elements.filter(el => el.type === 'qr');
    const barcodeElements = elements.filter(el => el.type === 'barcode');
    
    console.log('Found', qrElements.length, 'QR elements and', barcodeElements.length, 'barcode elements');
    
    // Use debounce timer to prevent repeated updates
    const timer = setTimeout(() => {
      // Update only elements that don't have dataUrl
      if (qrElements.length > 0) {
        const qrElementsToUpdate = qrElements.filter(el => !qrDataUrls[el.id]);
        
        if (qrElementsToUpdate.length > 0) {
          console.log(`Updating ${qrElementsToUpdate.length} QR elements that don't have dataUrl`);
          
          qrElementsToUpdate.forEach(el => {
            console.log('Updating QR data URL for element:', el.id, 'with id hash:', el.id.substring(0, 8));
            updateQrDataUrl(el as any);
          });
        } else {
          console.log('All QR elements already have dataUrl');
        }
      }
      
      if (barcodeElements.length > 0) {
        const barcodeElementsToUpdate = barcodeElements.filter(el => !barcodeDataUrls[el.id]);
        
        if (barcodeElementsToUpdate.length > 0) {
          console.log(`Updating ${barcodeElementsToUpdate.length} barcode elements that don't have dataUrl`);
          
          barcodeElementsToUpdate.forEach(el => {
            console.log('Updating barcode data URL for element:', el.id, 'with id hash:', el.id.substring(0, 8));
            updateBarcodeDataUrl(el as any);
          });
        } else {
          console.log('All barcode elements already have dataUrl');
        }
      }
    }, 500); // Add delay as 500ms to prevent repeated updates
    
    // Clear timer when unmount or dependency changes
    return () => clearTimeout(timer);
  }, [elements, qrDataUrls, barcodeDataUrls, updateQrDataUrl, updateBarcodeDataUrl]);
  
  // Set keyboard shortcuts
  useEffect(() => {
    if (!isClient) return;
    
    const handleKeyDown = (e: KeyboardEvent) => {
      // Ctrl+Z (Undo)
      if ((e.ctrlKey || e.metaKey) && e.key === 'z' && !e.shiftKey) {
        e.preventDefault();
        undo();
      }
      // Ctrl+Y or Ctrl+Shift+Z (Redo)
      else if ((e.ctrlKey || e.metaKey) && (e.key === 'y' || (e.key === 'z' && e.shiftKey))) {
        e.preventDefault();
        redo();
      }
      // Delete/Backspace
      else if ((e.key === 'Delete' || e.key === 'Backspace') && selectedId) {
        e.preventDefault();
        deleteElement(selectedId);
        selectElement(null);
      }
      // Ctrl+D (Duplicate)
      else if ((e.ctrlKey || e.metaKey) && e.key === 'd' && selectedId) {
        e.preventDefault();
        duplicateElement(selectedId);
      }
    };
    
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [undo, redo, deleteElement, duplicateElement, selectedId, selectElement]);

  // Event handlers
  
  /**
   * Function for fetching batch data and applying
   */
  const fetchAndApplyBatch = useCallback(
    async (batchNumber: string, showQR?: string) => {
      if (!batchNumber) {
        message.error('Please enter batch number');
        return;
      }
      
      // Check if batch data has already been loaded
      if (batchAppliedRef.current[batchNumber]) {
        message.info('Batch data has already been loaded');
        return;
      }
      
      try {
        console.log(`Fetching batch data for batch number: ${batchNumber}`);
        // Clear cache of data that might cause errors
        clearCache();
        
        const result = await fetchBatchData(batchNumber);
        
        if (result) {
          console.log('Batch data fetched successfully', result);
          
          // Find existing template with ProductKey and CustomerKey first
          if (result.ProductKey || result.CustomerKey) {
            console.log('Checking for existing template with ProductKey:', result.ProductKey, 'CustomerKey:', result.CustomerKey);
            
            try {
              // Find existing template with ProductKey and CustomerKey
              const foundTemplateId = await findTemplateByProductAndCustomer(result.ProductKey, result.CustomerKey);
              
              if (foundTemplateId) {
                console.log(`Found template ID: ${foundTemplateId} for ProductKey: ${result.ProductKey}, CustomerKey: ${result.CustomerKey}`);
                message.info(`Found template for Product: ${result.ProductKey} Customer: ${result.CustomerKey || 'N/A'}`);
                
                // Load existing template
                const templateData = await loadTemplate(String(foundTemplateId));
                
                // Check if load template succeeded
                if (templateData) {
                  console.log('Template loaded successfully', templateData);
                  
                  // Update template data
                  setTemplateInfo({
                    name: templateData.templateInfo.name,
                    description: templateData.templateInfo.description,
                    productKey: result.ProductKey || templateData.templateInfo.productKey,
                    customerKey: result.CustomerKey || templateData.templateInfo.customerKey,
                    paperSize: templateData.templateInfo.paperSize,
                    orientation: templateData.templateInfo.orientation,
                    templateType: templateData.templateInfo.templateType,
                  });
                  
                  // Set canvas size according to loaded data
                  if (templateData.canvasSize) {
                    resizeCanvas(templateData.canvasSize);
                  }
                  
                  // Set elements according to loaded data
                  if (templateData.elements && Array.isArray(templateData.elements)) {
                    console.log(`Setting ${templateData.elements.length} elements from loaded template`);
                    selectElement(null);
                    setElements(templateData.elements);
                    
                    // Update QR codes and barcodes
                    setTimeout(() => {
                      console.log('Updating QR codes and barcodes after template load');
                      updateAllQrCodes(templateData.elements);
                      updateAllBarcodes(templateData.elements);
                    }, 300);
                    
                    // Set template loaded state
                    setTemplateLoaded(true);
                    templateLoadedRef.current = true;
                    
                    // Set template ID - support different ID formats
                    const templateId = foundTemplateId.toString();
                    setTemplateId(templateId);
                    
                    // Set batch data load success
                    batchAppliedRef.current[batchNumber] = true;
                    
                    // No need to create additional elements from batch data
                    message.success('Loaded template and batch data successfully');
                    return;
                  }
                }
              }
            } catch (error) {
              console.error('Error in checking existing template:', error);
              message.error('An error occurred while checking existing template');
            }
          }
          
          // If no template found or unable to load template, create elements from batch data
          console.log('Building elements from batch data...');
          
          // Create elements from batch data
          const options = { showQR: showQR === 'true' || showQR === '1' };
          console.log('Building elements with options:', options);
          
          const batchElements = buildElementsFromBatch(result, options);
          
          console.log(`Built ${batchElements.length} elements from batch data`);
          
          // Update elements by using function that adjusts value instead of passing function
          const newElements = elements.length > 0 
            ? [...elements, ...batchElements] 
            : batchElements;
            
          console.log(`Setting ${newElements.length} elements (${elements.length} existing + ${batchElements.length} new)`);
          setElements(newElements);
          
          // Update QR codes and barcodes
          setTimeout(() => {
            console.log('Updating QR codes and barcodes after batch data applied');
            updateAllQrCodes(newElements.filter(el => el.type === 'qr'));
            updateAllBarcodes(newElements.filter(el => el.type === 'barcode'));
          }, 300); // Add delay as 300ms
          
          message.success('Loaded batch data successfully');
          batchAppliedRef.current[batchNumber] = true;
        } else {
          console.error('Failed to load batch data');
          message.error('An error occurred while loading batch data');
        }
      } catch (error) {
        console.error('Error in fetchAndApplyBatch:', error);
        message.error('An error occurred while fetching batch data');
      }
    },
    [buildElementsFromBatch, 
     fetchBatchData, 
     updateAllQrCodes, 
     updateAllBarcodes, 
     elements, 
     setElements, 
     clearCache, 
     findTemplateByProductAndCustomer, 
     loadTemplate, 
     selectElement, 
     setTemplateInfo, 
     resizeCanvas, 
     setTemplateId]
  );
  
  /**
   * Add new element
   */
  const handleAddElement = useCallback((type: string) => {
    let newElement: ElementType;
    
    const centerX = canvasSize.width / 2 - 50;
    const centerY = canvasSize.height / 2 - 50;
    
    switch (type) {
      case 'text':
        newElement = {
          id: uuidv4(),
          type: 'text',
          x: centerX,
          y: centerY,
          width: 100,
          height: 30,
          text: 'Text',
          fontSize: 16,
          fontFamily: 'Arial',
          fill: '#000000',
          align: 'center',
          draggable: true,
          visible: true
        };
        break;
      case 'rect':
        newElement = {
          id: uuidv4(),
          type: 'rect',
          x: centerX,
          y: centerY,
          width: 100,
          height: 100,
          fill: '#e0e0e0',
          draggable: true,
          visible: true
        };
        break;
      case 'barcode':
        newElement = {
          id: uuidv4(),
          type: 'barcode',
          x: centerX,
          y: centerY,
          width: 200,
          height: 90,
          value: '12345678',
          format: 'CODE128',
          fill: '#000000',
          draggable: true,
          visible: true,
          displayValue: true,
          fontSize: 14,
          fontFamily: 'monospace',
          textAlign: 'center',
          textPosition: 'bottom',
          textMargin: 2,
          background: '#FFFFFF',
          lineColor: '#000000',
          margin: 5
        };
        break;
      case 'qr':
        newElement = {
          id: uuidv4(),
          type: 'qr',
          x: centerX,
          y: centerY,
          width: 100,
          height: 100,
          value: 'https://example.com',
          fill: '#000000',
          draggable: true,
          visible: true
        };
        break;
      case 'line':
        newElement = {
          id: uuidv4(),
          type: 'line',
          x: centerX,
          y: centerY,
          width: 200,
          height: 2,
          fill: '#000000',
          draggable: true,
          visible: true
        };
        break;
      default:
        return;
    }
    
    addElement(newElement);
    selectElement(newElement.id);
    
    if (type === 'qr') {
      setTimeout(() => {
        updateQrDataUrl(newElement as any);
      }, 100);
    } else if (type === 'barcode') {
      setTimeout(() => {
        updateBarcodeDataUrl(newElement as any);
      }, 100);
    }
  }, [canvasSize, addElement, selectElement, updateQrDataUrl, updateBarcodeDataUrl]);
  
  /**
   * Rotate selected element
   */
  const handleRotateElement = useCallback(() => {
    if (!selectedId) return;
    
    const selectedElement = elements.find(el => el.id === selectedId);
    if (selectedElement) {
      const newRotation = ((selectedElement.rotation || 0) + 90) % 360;
      updateElementProperty(selectedId, 'rotation', newRotation);
    }
  }, [selectedId, elements, updateElementProperty]);
  
  /**
   * Save template settings
   */
  const handleSaveTemplateSettings = useCallback((newTemplateInfo: TemplateInfo, newCanvasSize: CanvasSize) => {
    setTemplateInfo(newTemplateInfo);
    resizeCanvas(newCanvasSize);
    setTemplateInfoModal(false);
  }, [resizeCanvas]);
  
  /**
   * Save template when clicking save button on toolbar
   */
  const handleSaveTemplate = async () => {
    try {
      // Create template data
      const templateData = {
        settings: {
          name: templateInfo.name || 'Untitled Template',
          description: templateInfo.description || '',
          engine: 'ZPL',
          paperSize: templateInfo.paperSize || '4x4',
          orientation: templateInfo.orientation || 'Portrait',
          customWidth: canvasSize.width,
          customHeight: canvasSize.height,
          templateType: templateInfo.templateType || 'INNER',
        },
        elements: elements,
        productKey: templateInfo.productKey || '',
        customerKey: templateInfo.customerKey || '',
        canvasSize: canvasSize,
      };

      // Check basic information required
      if (!templateData.settings.name.trim()) {
        message.error('Please enter template name');
        return;
      }

      message.loading({ content: 'Saving template...', key: 'savingTemplate', duration: 0 });

      // Use onSave callback if provided
      if (onSave) {
        await onSave(templateData);
        message.success({ content: 'Template saved successfully', key: 'savingTemplate' });
        return;
      }

      // Or use saveTemplate function from useTemplateActions
      const saved = await saveTemplate(
        templateInfo, 
        elements, 
        canvasSize, 
        batchNo || undefined
      );
      
      if (saved) {
        message.success({ content: 'Template saved successfully', key: 'savingTemplate' });
        // Save last saved time
        setLastSavedTime(new Date().toLocaleTimeString());
      } else {
        message.error({ content: 'Failed to save template', key: 'savingTemplate' });
      }
    } catch (error: any) {
      console.error('Error saving template:', error);
      message.error({ 
        content: `An error occurred while saving template: ${error.message || 'Unknown error'}`, 
        key: 'savingTemplate' 
      });
      
      // If error is related to authentication (401)
      if (error.response && error.response.status === 401) {
        message.error('You do not have permission to save template. Please log in again');
        setTimeout(() => {
          window.location.href = '/login?redirect=' + encodeURIComponent(window.location.pathname + window.location.search);
        }, 1000);
      }
    }
  };
  
  /**
   * Export template as JSON
   */
  const handleExportTemplate = useCallback(() => {
    const jsonData = exportTemplateAsJson(elements, canvasSize);
    
    // Create Blob and URL
    const blob = new Blob([jsonData], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    
    // Create download link
    const a = document.createElement('a');
    a.href = url;
    a.download = `${templateInfo.name || 'template'}-${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(a);
    a.click();
    
    // Clean up
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    message.success('Export template successfully');
  }, [exportTemplateAsJson, elements, canvasSize, templateInfo.name]);
  
  /**
   * Import template from JSON
   */
  const handleImportTemplate = useCallback(() => {
    setImportModal(true);
  }, []);
  
  /**
   * Confirm import of JSON
   */
  const handleConfirmImport = useCallback(() => {
    try {
      // Clear cache before importing new template
      clearCache();
      
      const result = importTemplateFromJson(importJson);
      
      if (result) {
        replaceAllElements(result.elements);
        resizeCanvas(result.canvasSize);
        
        // Add delay in updating QR and Barcode after importing
        setTimeout(() => {
          const qrElements = result.elements.filter(el => el.type === 'qr');
          const barcodeElements = result.elements.filter(el => el.type === 'barcode');
          
          if (qrElements.length > 0) {
            console.log(`Updating ${qrElements.length} QR elements after JSON import`);
            updateAllQrCodes(qrElements);
          }
          
          if (barcodeElements.length > 0) {
            console.log(`Updating ${barcodeElements.length} barcode elements after JSON import`);
            updateAllBarcodes(barcodeElements);
          }
        }, 500);
        
        setImportModal(false);
        setImportJson('');
        message.success('Import template successfully');
      }
    } catch (error: any) {
      message.error(`An error occurred while importing template: ${error.message}`);
    }
  }, [importJson, importTemplateFromJson, replaceAllElements, resizeCanvas, updateAllQrCodes, updateAllBarcodes, clearCache]);
  
  // Update function to respond to "Use Batch Data" button
  const handleUseBatchData = useCallback(() => {
    if (!batchNo) {
      message.error('Please enter Batch number');
      return;
    }
    
    // Call batch data fetching function
    fetchAndApplyBatch(batchNo);
  }, [batchNo, fetchAndApplyBatch]);

  return (
    <div className="template-designer">
      <Layout style={{ minHeight: '100vh' }}>
        <Header style={{ paddingLeft: 16, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <div style={{ color: '#fff', fontSize: '18px', fontWeight: 'bold' }}>
            Label Template Designer
          </div>
          <DesignerToolbar
            onSave={handleSaveTemplate}
            onExport={handleExportTemplate}
            onImport={handleImportTemplate}
            onUndo={undo}
            onRedo={redo}
            onDelete={() => selectedId && deleteElement(selectedId)}
            onZoomIn={zoomIn}
            onZoomOut={zoomOut}
            onTemplateSettings={() => setTemplateInfoModal(true)}
            onDuplicate={() => selectedId && duplicateElement(selectedId)}
            onRotate={handleRotateElement}
            canUndo={canUndo}
            canRedo={canRedo}
            canDelete={!!selectedId}
            canDuplicate={!!selectedId}
            isSaving={isSaving}
            zoom={zoom}
          />
        </Header>
        <Layout>
          <Sider width={250} style={{ background: '#fff' }}>
            <DesignerSidebar
              onAddElement={handleAddElement}
              batchNo={batchNo}
              onBatchNoChange={setBatchNo}
              onApplyBatchData={handleUseBatchData}
              isLoading={batchLoading}
            />
          </Sider>
          
          <Content style={{ padding: '20px', background: '#f0f2f5' }}>
            <div style={{ 
              background: '#fff', 
              padding: '16px', 
              borderRadius: '4px',
              boxShadow: '0 1px 2px rgba(0,0,0,0.1)',
              height: 'calc(100vh - 104px)',
              overflow: 'auto'
            }}>
              <div
                style={{
                  border: '1px solid #ddd',
                  width: '100%',
                  height: '100%',
                  display: 'flex',
                  justifyContent: 'center',
                  alignItems: 'center',
                  position: 'relative',
                  overflow: 'auto'
                }}
              >
                <div
                  style={{
                    transform: `scale(${zoom})`,
                    transformOrigin: '50% 50%',
                    position: 'relative'
                  }}
                >
                  {isClient && (
                    <Stage
                      width={canvasSize.width}
                      height={canvasSize.height}
                      ref={stageRef}
                      style={{ 
                        background: '#fff',
                        boxShadow: '0 0 10px rgba(0,0,0,0.2)'
                      }}
                      onClick={(e: any) => {
                        // Cancel selection if clicking on empty area
                        if (e.target === e.currentTarget) {
                          selectElement(null);
                        }
                      }}
                    >
                      <Layer>
                        {/* Show grid lines if needed */}
                        {FEATURES.SNAPPING.ENABLED && Array.from({ length: Math.ceil(canvasSize.width / FEATURES.SNAPPING.GRID_SIZE) }).map((_, i) => (
                          <Line
                            key={`vgrid-${i}`}
                            points={[i * FEATURES.SNAPPING.GRID_SIZE, 0, i * FEATURES.SNAPPING.GRID_SIZE, canvasSize.height]}
                            stroke="#ddd"
                            strokeWidth={i % 5 === 0 ? 0.5 : 0.2}
                          />
                        ))}
                        {FEATURES.SNAPPING.ENABLED && Array.from({ length: Math.ceil(canvasSize.height / FEATURES.SNAPPING.GRID_SIZE) }).map((_, i) => (
                          <Line
                            key={`hgrid-${i}`}
                            points={[0, i * FEATURES.SNAPPING.GRID_SIZE, canvasSize.width, i * FEATURES.SNAPPING.GRID_SIZE]}
                            stroke="#ddd"
                            strokeWidth={i % 5 === 0 ? 0.5 : 0.2}
                          />
                        ))}
                        
                        {/* Show elements */}
                        {elements.map((el) => (
                          <Group
                            key={el.id}
                            id={el.id}
                            draggable={!el.locked && (el.draggable !== false)}
                            x={el.x}
                            y={el.y}
                            width={el.width}
                            height={el.height}
                            rotation={el.rotation || 0}
                            onClick={(e: any) => {
                              // Select element
                              e.cancelBubble = true;
                              selectElement(el.id);
                            }}
                            visible={el.visible !== false}
                            opacity={el.visible === false ? 0.4 : 1}
                            onDragEnd={(e: any) => {
                              // Update position when dragging ends
                              const { x, y } = e.target.position();
                              updateElementProperty(el.id, 'x', x);
                              updateElementProperty(el.id, 'y', y);
                            }}
                            onTransformEnd={(e: any) => {
                              // Update size and rotation when resizing ends
                              const node = e.target;
                              const scaleX = node.scaleX();
                              const scaleY = node.scaleY();
                              
                              // Reset scale and update size
                              node.scaleX(1);
                              node.scaleY(1);
                              
                              const updatedEl = {
                                ...el,
                                x: node.x(),
                                y: node.y(),
                                width: Math.max(5, node.width() * scaleX),
                                height: Math.max(5, node.height() * scaleY),
                                rotation: node.rotation()
                              };
                              
                              updateElement(updatedEl);
                            }}
                          >
                            <ElementRenderer
                              element={el}
                              qrDataUrls={qrDataUrls}
                              qrImages={qrImages}
                              barcodeDataUrls={barcodeDataUrls}
                              barcodeImages={barcodeImages}
                              updateQrDataUrl={updateQrDataUrl}
                              updateBarcodeDataUrl={updateBarcodeDataUrl}
                              isSelected={selectedId === el.id}
                            />
                            
                            {/* Show border around selected element */}
                            {selectedId === el.id && (
                              <Rect
                                x={0}
                                y={0}
                                width={el.width}
                                height={el.height}
                                stroke="#1890ff"
                                strokeWidth={1}
                                dash={[4, 4]}
                                fill="transparent"
                              />
                            )}
                          </Group>
                        ))}
                        
                        {/* Transformer for resizing selected element */}
                        {selectedId && (
                          <Transformer
                            ref={trRef}
                            rotateEnabled={true}
                            keepRatio={false}
                            boundBoxFunc={(oldBox, newBox) => {
                              // Limit size to not get too small
                              if (newBox.width < 5 || newBox.height < 5) {
                                return oldBox;
                              }
                              return newBox;
                            }}
                          />
                        )}
                      </Layer>
                    </Stage>
                  )}
                </div>
              </div>
            </div>
          </Content>
        </Layout>
      </Layout>
      
      {/* Modal for template settings */}
      <TemplateSettingsModal
        visible={templateInfoModal}
        onCancel={() => setTemplateInfoModal(false)}
        onSave={handleSaveTemplateSettings}
        templateInfo={templateInfo}
        canvasSize={canvasSize}
        loading={isSaving}
      />
      
      {/* Modal for importing JSON */}
      <Modal
        title="Import template from JSON"
        open={importModal}
        onCancel={() => {
          setImportModal(false);
          setImportJson('');
        }}
        onOk={handleConfirmImport}
        width={700}
      >
        <Input.TextArea
          value={importJson}
          onChange={(e) => setImportJson(e.target.value)}
          placeholder="Paste JSON here..."
          rows={10}
        />
      </Modal>
    </div>
  );
};

export default TemplateDesigner; 