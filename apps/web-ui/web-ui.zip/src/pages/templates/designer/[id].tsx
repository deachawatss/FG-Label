import React, { useEffect, useState } from 'react';
import { useRouter } from 'next/router';
import axios from 'axios';
import { message, Spin } from 'antd';
import RequireAuth from '@/components/RequireAuth';
import TemplateDesigner from '../../../components/TemplateDesigner';

// Helper function to get API URL
const getApiBaseUrl = () => {
  const baseUrl = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5051/api';
  return baseUrl;
};

// Helper function to get Auth headers
const getAuthHeaders = () => {
  const token = localStorage.getItem('authToken');
  // Check if token exists
  if (!token) {
    message.error('Authentication token not found. Please login again.');
    // Refresh page to request login
    setTimeout(() => {
      window.location.href = '/login?redirect=' + encodeURIComponent(window.location.pathname + window.location.search);
    }, 1000);
    return {};
  }
  return token ? { Authorization: `Bearer ${token}` } : {};
};

export default function TemplateDesignerPage() {
  const router = useRouter();
  const { id } = router.query;
  const batchNo = router.query.batchNo as string;
  
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [template, setTemplate] = useState<any>(null);
  
  // Load template data
  useEffect(() => {
    const fetchTemplate = async () => {
      if (!id) return;
      
      setLoading(true);
      try {
        let apiUrl = '';
        let response;
        
        // If batchNo exists, use getOrCreateByBatch API
        if (batchNo) {
          apiUrl = `${getApiBaseUrl()}/templates/getOrCreateByBatch?batchNo=${batchNo}`;
          response = await axios.get(apiUrl, { headers: getAuthHeaders() });
          
          // Check if response.data.id matches the specified id
          if (response.data.id.toString() !== id) {
            // If not matching, navigate to the page with correct id
            router.replace(`/templates/designer/${response.data.id}?batchNo=${batchNo}`);
            return;
          }
        } else {
          // If no batchNo, use standard API
          apiUrl = `${getApiBaseUrl()}/templates/${id}`;
          response = await axios.get(apiUrl, { headers: getAuthHeaders() });
        }
        
        setTemplate(response.data);
      } catch (err: any) {
        console.error('Error fetching template:', err);
        setError(err.message || 'Failed to load template');
        message.error('Failed to load template');
      } finally {
        setLoading(false);
      }
    };
    
    fetchTemplate();
  }, [id, batchNo, router]);
  
  // Save changes
  const handleSave = async (templateData: any) => {
    if (!id) return;
    
    try {
      const headers = getAuthHeaders();
      // Check if token exists
      if (!headers.Authorization) {
        message.error('Authentication token not found. Please login again.');
        // Refresh page to request login
        setTimeout(() => {
          window.location.href = '/login?redirect=' + encodeURIComponent(window.location.pathname + window.location.search);
        }, 1000);
        return;
      }
      
      const apiUrl = `${getApiBaseUrl()}/templates/${id}`;
      
      // Prepare data to send
      const updateData = {
        name: templateData.settings.name,
        description: templateData.settings.description,
        productKey: templateData.productKey || '',
        customerKey: templateData.customerKey || '',
        engine: templateData.settings.engine || 'ZPL',
        paperSize: templateData.settings.paperSize || '4x4',
        orientation: templateData.settings.orientation || 'Portrait',
        customWidth: templateData.settings.customWidth,
        customHeight: templateData.settings.customHeight,
        content: JSON.stringify(templateData),
        components: templateData.elements.map((element: any) => ({
          componentId: element.id,
          componentType: element.type,
          x: element.x,
          y: element.y,
          w: element.width,
          h: element.height,
          staticText: element.text,
          placeholder: element.placeholder,
          fontName: element.fontFamily,
          fontSize: element.fontSize,
          fontWeight: element.fontWeight,
          fontStyle: element.fontStyle,
          fill: element.fill,
          align: element.align,
          barcodeFormat: element.format,
          layer: element.layer,
          visible: true
        }))
      };
      
      // Send data to API
      await axios.put(apiUrl, updateData, { headers });
      
      message.success('Template saved successfully');
      
      // If batchNo exists, navigate back to batch-search page
      if (batchNo) {
        router.push(`/batch-search?batchNo=${batchNo}`);
      } else {
        router.push('/templates');
      }
    } catch (err: any) {
      console.error('Error saving template:', err);
      if (err.response && err.response.status === 401) {
        message.error('You do not have permission to save this template. Please login again.');
        setTimeout(() => {
          window.location.href = '/login?redirect=' + encodeURIComponent(window.location.pathname + window.location.search);
        }, 1000);
      } else {
        message.error('Error saving template: ' + (err.message || 'Unknown error'));
      }
    }
  };
  
  if (loading) {
    return (
      <RequireAuth>
        <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh' }}>
          <Spin size="large">
            <div style={{ padding: '50px', textAlign: 'center' }}>
              <p style={{ marginTop: '20px' }}>Loading template...</p>
            </div>
          </Spin>
        </div>
      </RequireAuth>
    );
  }
  
  if (error) {
    return (
      <RequireAuth>
        <div style={{ textAlign: 'center', marginTop: '50px' }}>
          <h2>Error Loading Template</h2>
          <p>{error}</p>
          <button onClick={() => router.back()}>Go Back</button>
        </div>
      </RequireAuth>
    );
  }
  
  return (
    <RequireAuth>
      <TemplateDesigner initialTemplate={template} onSave={handleSave} />
    </RequireAuth>
  );
} 